#ifndef  _SW_ALLALL_FLIP_CONDITIONALS_H_
#define  _SW_ALLALL_FLIP_CONDITIONALS_H_

/* Header just needed by test programs. Not used by anything real. */
void percolate(double* bonds, int *ptr, double* biases, int nn);
void flip_clusters(double* flips, double* cprobs, int* ptr, double* biases, int nn);

#endif /* #ifndef  _SW_ALLALL_FLIP_CONDITIONALS_H_  */
